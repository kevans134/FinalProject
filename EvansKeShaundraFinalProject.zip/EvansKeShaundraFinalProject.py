from tkinter import *
root = Tk()
root.title('Crash Course Cash register program')
#the program will ask for your name
print("Please enter your name.")
label_1 = Label(root,text="Enter your Name",bg= "red", fg="white")
entry_1 = Entry(root)
my_img= ImageTk.PhotoImage(Image.open("images/lilyheader.png"))



#this is the grid layout of the entry box of name
label_1.grid(row=0)
entry_1.grid(row=0, column=1)


#open a new window
top = Toplevel()
Tops = Frame (root, width= 1350, height=100, bd=12, relief="raise")
Tops.pack(side=TOP)
lblTitle= Label(Tops, font=('arial',50,'bold'),text="Menu")
lblTitle.grid(row=0, column=0)

BottomMainFrame = Frame (root, width=1350, height=650, bd=12, relief="raise")
BottomMainFrame.pack(side=BOTTOM)

f1 = Frame (BottomMainFrame, width=1350, height=650, bd=12, relief="raise")
f1.pack(side=LEFT)
f2= Frame (BottomMainFrame, width=1350, height=650, bd=12, relief="raise")
f2.pack(side=RIGHT)
f3 = Frame (BottomMainFrame, width=1350, height=650, bd=12, relief="raise")
f3.pack(side=BOTTOM)
#listing the variables
var1=IntVar()
var2=IntVar()
var3=IntVar()
var4=IntVar()
var5=IntVar()
var6=IntVar()
var7=IntVar()
var8=IntVar()
var9=IntVar()
var10=IntVar()
#Then setting the variables to as a string
var1.set(0)
var2.set(0)
var3.set(0)
var4.set(0)
var5.set(0)
var6.set(0)
var7.set(0)
var8.set(0)
var9.set(0)
var10.set(0)
# To defined the variables
varFries = StringVar
varFries.set("0")
coconutIcecream = StringVar
coconutIcecream.set("0")
veganYogurt= StringVar
veganYogurt.set("0")

blueberryMuffin= StringVar
blueberryMuffin.set("0")
vanillaCupcake = StringVar
vanillaCupcake.set("0")
strawberryCheesecake = StringVar
strawberryCheesecake.set("0")

def iExit ():
    qExit= messagebox.askyesno("Do you want to quit?")
    if qExit > 0:
        root.destroy()
        return
def Reset ():
    var1.set(0)
    var2.set(0)
    var3.set(0)
    var4.set(0)
    var5.set(0)
    var6.set(0)
    var7.set(0)
    var8.set(0)
    var9.set(0)
    var10.set(0)
#Now defined each variables so
def chkAppleFries ():
    if (var2.get() == 1):
        txtAppleFries.configure(state = NORMAL)
        varFries.set("")
    elif(var2.get () == 0):
        txtAppleFries.configure(state = DISABLED)
        varFries.set("0")

def coconutIcecream():
    if (var3.get() == 1):
        txtCoconutIcecream.configure(state=NORMAL)
        varCoconutIcecream.set("")
     elif (var3.get() == 0):
         txtCoconutIcecream.configure(state=DISABLED)
         varCoconutIcecream.set("0")

    def chkAppleFries():
        if (var4.get() == 1):
            txtAppleFries.configure(state=NORMAL)
            varFries.set("")
        elif (var4.get() == 0):
            txtAppleFries.configure(state=DISABLED)
            varFries.set("0")

def veganYogurt():
    if (var5.get() == 1):
        txtVeganYogurt.configure(state=NORMAL)
         varVeganYogurt.set("")
     elif (var5.get() == 0):
          txtVeganYogurt.configure(state=DISABLED)
          varVeganYogurt.set("0")

def chkAppleFries ():
    if (var2.get() == 1):
        txtAppleFries.configure(state = NORMAL)
        varFries.set("")
    elif(var2.get () == 0):
        txtAppleFries.configure(state = DISABLED)
        varFries.set("0")

def chkblueberryMuffin  ():
    if (var2.get() == 1):
        txtBlueberryMuffin .configure(state = NORMAL)
        varBlueberryMuffin .set("")
    elif(var2.get () == 0):
        txtBlueberryMuffin .configure(state = DISABLED)
        varBlueberryMuffin .set("0")

def chkvanillaCupcake ():
    if (var2.get() == 1):
        txtVanillaCupcake.configure(state = NORMAL)
        varVanillaCupcake.set("")
    elif(var2.get () == 0):
        txtVanillaCupcake.configure(state = DISABLED)
        varVanillaCupcake.set("0")

def chkstrawberryCheesecake ():
    if (var2.get() == 1):
        txtStrawberryCheesecake.configure(state = NORMAL)
        varStrawberryCheesecake.set("")
    elif(var2.get () == 0):
        txtStrawberryCheesecake.configure(state = DISABLED)
        varStrawberryCheesecake.set("0")

lblMeal= Label(f1,font=('arial', 18, 'bold'), text="Sides")
lblMeal.grid(row=0, column=0)

appleFries =Checkbutton(f1, text="Apple Fries\t\t\t$1.50",variable=var1, onvalue=1, offvalue=0, font=('arial',18,'bold')).grid(row=1,column=0, sticky=W)
txtAppleFries = Entry (f1,font=('arial', 18, 'bold'), textvariable= varFries, width =6, justify= 'left',state=DISABLED )

coconutIcecream =Checkbutton(f1, text="Coconut Icecream\t\t\t$3.50",variable=var1, onvalue=1, offvalue=0, font=('arial',18,'bold')).grid(row=1,column=0, sticky=W)
txtCoconutIcecream = Entry (f1,font=('arial', 18, 'bold'), textvariable= varCoconutIcecream, width =6, justify= 'left',state=DISABLED )

veganYogurt =Checkbutton(f1, text="Vegan Yogurt\t\t\t$2.50",variable=var1, onvalue=1, offvalue=0, font=('arial',18,'bold')).grid(row=1,column=0, sticky=W)
txtVeganYogurt = Entry (f1,font=('arial', 18, 'bold'), textvariable= varVeganYogurt, width =6, justify= 'left',state=DISABLED )

lblspace=Label(f1, text="\n\n\n\n\n\n\n\n")
lblspace.grid(row=9, column=0)


lblMeal= Label(f2,font=('arial', 18, 'bold'), text="Baked Goods")
lblMeal.grid(row=0, column=0)


blueberryMuffin = Checkbutton(f2, text="Blueberry Muffin\t\t\t$5.99",variable=var1, onvalue=1, offvalue=0, font=('arial',18,'bold')).grid(row=1,column=0, sticky=W)
txtBlueberryMuffin = Entry (f2,font=('arial', 18, 'bold'), textvariable= varBlueberryMuffin, width =6, justify= 'left',state=DISABLED )

vanillaCupcake = Checkbutton(f2, text="Vanilla Cupcake\t\t\t$6.99",variable=var1, onvalue=1, offvalue=0, font=('arial',18,'bold')).grid(row=1,column=0, sticky=W)
txtVanillaCupcake = Entry (f2,font=('arial', 18, 'bold'), textvariable= varVanillaCupcake, width =6, justify= 'left',state=DISABLED )

strawberryCheesecake = Checkbutton(f2, text="Vegan Strawberry Cheesecake\t\t\t$8.99",variable=var1, onvalue=1, offvalue=0, font=('arial',18,'bold')).grid(row=1,column=0, sticky=W)
txtStrawberryCheesecake = Entry (f2,font=('arial', 18, 'bold'), textvariable= varStrawberryCheesecake, width =6, justify= 'left',state=DISABLED )

lblspace=Label(f2, text="\n\n\n\n\n\n\n\n")
lblspace.grid(row=9, column=0)

lblMeal= Label(f3,font=('arial', 18, 'bold'), text="Payment")
lblMeal.grid(row=0, column=0)

lblPaymentMethod =Label (f3, font=('arial', 14, 'bold'), text="Payment Method", bd=10, width= 16, anchor='W')
lblPaymentMethod.grid(row =0, column=0)

lblChange =Label (f3, font=('arial', 14, 'bold'), text="Payment Method", bd=10, width= 16, anchor='W')
lblChange.grid (row=0, column=1)
lblPaymentMethod =Label (f3, font=('arial', 14, 'bold'), text="Payment Method", bd=10, width= 16, anchor='W')

btnTotal =Button(f3, padx= 16, pady=1, bd=4, fg="black",font=('arial',16, 'bold'), width=5, text="Total").grid(row=4, column=0)

btnReset =Button(f3, padx= 16, pady=1, bd=4, fg="black",font=('arial',16, 'bold'), width=5, text="Reset").grid(row=4, column=1)

btnExit =Button(f3, padx= 16, pady=1, bd=4, fg="black",font=('arial',16, 'bold'), width=5, text="Exit").grid(row=4, column=2)

lblspace=Label (f3, text="\n\n\n\n\n\n\n")
lblspace.grid(row =5, column=0)


root.mainloop()
